#ifndef SINADATE_H
#define SINADATE_H


class SinaDate
{
    public:
        SinaDate();
        virtual ~SinaDate();

    protected:

    private:
};

#endif // SINADATE_H
