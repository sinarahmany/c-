#ifndef SIAMAKDATE_H
#define SIAMAKDATE_H
#include <stdio.h>
#include <iostream>
#include <string>
#include <windows.h>

void strColor(std::string, int, int);
class SiamakDate{
    private:
        // 3 integers for Day, year and Month
        int day;//second;
        int month;//minute;
        int year;//hour;

    public:
        // 6 Access functions to get and set data members
        int getDay();
        void setDay(int day);

        int getMonth();
        void setMonth(int month);

        int getYear();
        void setYear(int year);

        // 3 Constructors (default, overloaded and copy) - default constructor
        SiamakDate();

        // 3 Constructors (default, overloaded and copy) - overloaded constructor
        SiamakDate(int day, int month, int year);

        // 3 Constructors (default, overloaded and copy) - copy constructor
        SiamakDate(const SiamakDate &obj);

        // 1 Destructor (empty)
        ~SiamakDate();

        // 3 utility function for checking year and month and day values - check Day
        std::string checkSiamakDay(int);

        // 3 utility function for checking year and month and day values - check month
        std::string checkSiamakMonth(int);

        // 3 utility function for checking year and month and day values - check year (Extra bonus to implement leap years and February days)
        std::string checkSiamakYear(int);

        //1 utility function to print the date object you create
        void printSiamakDate();
    };

#endif // SIAMAKDATE_H

