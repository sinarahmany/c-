#include "SiamakDate.h"

    // 3 Constructors (default, overloaded and copy) - default constructor
    // default constructor
    SiamakDate::SiamakDate():SiamakDate(1,1,1970){
        strColor("\n**** default constructor called with 1.1.1970 ****\n", 8, 1);
    }

    // 3 Constructors (default, overloaded and copy) - overloaded constructor
    // overloaded constructor
    SiamakDate::SiamakDate(int month, int day, int year){
        this->day = day;
        this->month = month;
        this->year = year;
        strColor("\n**** overloaded constructor called with month: " + std::to_string(this->month) +
                                                        + " day: " + std::to_string(this->day) +
                                                        + " year: " + std::to_string(this->year) + "****\n", 8, 1);
    }

    // 3 Constructors (default, overloaded and copy) - copy constructor
    // copy constructor
    SiamakDate::SiamakDate(const SiamakDate &obj){
        this->day = obj.day;
        this->month = obj.month;
        this->year = obj.year;
        strColor("\n**** copy constructor called with month: " + std::to_string(this->month) +
                                                        + " day: " + std::to_string(this->day) +
                                                        + " year: " + std::to_string(this->year) + "****\n", 8, 1);
    }

    // 1 Destructor (empty)
    SiamakDate::~SiamakDate(){
    }

    // 6 Access functions to get and set data members
    // 1 Access function to get Day member
    int SiamakDate::getDay(){
        return day;
    }

    // 2 Access function to set Day member
    void SiamakDate::setDay(int day){
        this->day = day;
    }

    // 3 Access function to get Month member
    int SiamakDate::getMonth(){
        return month;
    }

    // 4 Access function to set Month member
    void SiamakDate::setMonth(int month){
        this->month = month;
    }

    // 5 Access function to get Year member
    int SiamakDate::getYear(){
        return year;
    }

    // 6 Access function to set Year member
    void SiamakDate::setYear(int year){
        this->year = year;
    }

    // 3 utility function for checking year and month and day values - check Day
    // 1 checking day and return string format
    std::string SiamakDate::checkSiamakDay(int day){
        if(day>0 && day<32){
            this->day = day;
            return(day<10 ? "0"+std::to_string(day) : std::to_string(day));
        }else {
            this->day = -1;
            return("-1");
        }
    }

    // 3 utility function for checking year and month and day values - check month
    // 1 checking month and return string format
    std::string SiamakDate::checkSiamakMonth(int month){
        if(month>0 && month<13){
            this->month = month;
            return(month<10 ? "0"+std::to_string(month) : std::to_string(month));
        } else{
            this->month = -1;
            return("-1");
        }
    }

    // 3 utility function for checking year and month and day values - check year
    // 1 checking year and return string format
    std::string SiamakDate::checkSiamakYear(int year){
        if(year>0){
            this->year = year;
            return(std::to_string(year));
        }else {
            this->year = -1;
            return("-1");
        }
    }

    // Extra bonus to  implement leap years and February days
    bool checkSiamakLeapYear(int year){
       if (((year%4 == 0) && (year%100 != 0)) || (year%400 == 0)) return true;
       return false;
    }

    // 1 utility function to print the date object you create
    void SiamakDate::printSiamakDate(){
        strColor("\nThe Date is: ", 14, 1);
        strColor(checkSiamakDay(this->day)+"/"+checkSiamakMonth(this->month)+"/"+checkSiamakYear(this->year),12,1);
        strColor("\nand " + std::to_string(this->year) + (checkSiamakLeapYear(this->year)?" is a":" is not a") + " Leap year.\n\n",14,1);
    }

    // A function to cout using 3 parameters, 1st:String, 2nd:ColorCode, 3rd:Times to print the string
    void strColor(std::string strText, int intColor, int intQty){
        HANDLE  hConsole;
        hConsole = GetStdHandle(STD_OUTPUT_HANDLE);                 // get access to the Console handler
        SetConsoleTextAttribute(hConsole, static_cast<int>(intColor%15==0?15:intColor%15)); // set console handler color based on intColor from 1 to 15
        for (int i=0; i<intQty; i++) std::cout<<strText;            // A loop to reprint the character for intQty times
        SetConsoleTextAttribute(hConsole, 15);                      // Set back console color
    return;
}
