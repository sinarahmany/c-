#include <iostream>
#include "SiamakDate.h"


int main()
{
    // A driver that demonstrates your code is working
    strColor("Hi, welcome to Date C++ Class\n" ,11,1);

    SiamakDate* aSiamakDate = new SiamakDate();
    (*aSiamakDate).printSiamakDate();

    SiamakDate* bSiamakDate = new SiamakDate(7,19,1974);
    (*bSiamakDate).printSiamakDate();

    SiamakDate* cSiamakDate = new SiamakDate(1,1,2020);
    (*cSiamakDate).printSiamakDate();

    return 0;
}
