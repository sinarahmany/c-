#include <iostream>
#include "Deep.h"

void printObject(Deep obj) {
	std::cout << obj.getData();
}

int main() {

	Deep object1(100);
	printObject(object1);// no more error!

	Deep object2(object1);
	object2.setData(1000);

	system("pause");
	return 0;
}