#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

int main() {

	std::ifstream infile;
	std::ofstream outfile;

	infile.open("pawPatrolInfo.txt");
	outfile.open("copy_pawPatrolInfo.txt");

	if (infile.fail()) {
		std::cerr << "pawPatrolInfo.txt is not readable." << std::endl;
	}

	if (outfile.fail()) {
		std::cerr << "copy process failed!" << std::endl;
	}

	std::string line;
	int lineNumber{ 1 };
	while(!infile.eof()){
		std::getline(infile, line);
		outfile << std::setw(3) << std::left << lineNumber << line << std::endl;
		lineNumber += 1;
	}

	//char c;
	//while(infile.get(c)){
	//	outfile << c;
	//}


	std::cout << "copy process completed successfully." << std::endl;

	infile.close();
	outfile.close();

	system("pause");
	return 0;
}

