#include <iostream>
#include <fstream>
#include <string>

int main() {

	std::string line{ "" };

	std::ofstream writeFile;

	writeFile.open("someData.txt", std::ios::app); // append

	if (!writeFile.is_open()) {
		std::cerr << "ERROR: file issues!";
	}

	std::cout << "enter some string <0 to exit>";
	while (std::getline(std::cin, line)){
		if (line == "0") break;
		writeFile << line << std::endl;
	}

	writeFile.close();
	system("pause");
	return 0;
}

