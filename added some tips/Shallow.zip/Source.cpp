#include <iostream>
#include "Shallow.h"

void printObject(Shallow obj) {
	std::cout << obj.getData();
}

int main() {

	Shallow object1(100);
	printObject(object1);// give error

	//Shallow object2(object1);
	//object2.setData(1000);

	system("pause");
	return 0;
}