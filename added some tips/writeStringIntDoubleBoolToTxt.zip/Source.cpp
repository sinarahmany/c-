#include <iostream>
#include <fstream>
#include <string>

int main() {

	int a{ 100 };
	double b{ 7.6 };
	bool c{ false };
	std::string d{ "hello io" };

	std::ofstream writeFile;

	writeFile.open("someData.txt", std::ios::out);

	writeFile << a << std::endl;
	writeFile << b << std::endl;
	writeFile << std::boolalpha << c << std::endl;
	writeFile << d << std::endl;


	writeFile.close();
	system("pause");
	return 0;
}

